import axios from 'axios'

const instance = axios.create({
    baseURL: 'https://mycinemagic-default-rtdb.firebaseio.com/'
})

export default instance