

import React from 'react'
import './WatchList.css'
import { useState, useEffect } from 'react'
import List from '../../Components/ListOfFilms/List'

import axios from '../../axios-movies'

const WatchList = () => {
    const [filmInfo, setFilmInfo] = useState([])


    useEffect(() => {
        axios.get('https://mycinemagic-default-rtdb.firebaseio.com/films.json')
            .then((response) => {
                if (response.data === null) {
                    document.querySelector(".watched-page").innerHTML = "Nothing on the list yet"
                }
                else {
                    let key = Object.keys(response.data)
                    let film = []
                    for (let i = 0; i < key.length; i++) {
                        film.push({
                            key: key[i],
                            title: response.data[key[i]].title,
                            year: response.data[key[i]].year,
                            imdb: response.data[key[i]].imdb,
                            type: response.data[key[i]].type,
                            status: response.data[key[i]].status,
                        })
                    }
                    setFilmInfo(film)
                }
            })
    })


    const deleteHandler = (index) => {
        axios.delete(`https://mycinemagic-default-rtdb.firebaseio.com/films/${filmInfo[index].key}.json`)
            .then(() => {
                setFilmInfo(filmInfo.splice(index, 1))
            });
    }


    return (
        < section className="watched-page" >

            <List film={filmInfo} deleteHandler={deleteHandler} />
        </section >
    )
}

export default WatchList