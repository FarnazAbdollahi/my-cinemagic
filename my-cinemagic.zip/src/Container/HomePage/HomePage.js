import React from 'react'
import './HomePage.css'

const HomePage = () => {


    return (
        <main className="home-page">
        </main>
    )
}

export default HomePage