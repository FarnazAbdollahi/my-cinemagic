import React, { createElement } from 'react'
import './Add.css'
import { Form, Button, Modal } from 'react-bootstrap'
import { useState } from 'react'
import axios from '../../axios-movies'

const Add = () => {

    const [title, setTitle] = useState('')
    const [year, setYear] = useState('')
    const [imdb, setIMDB] = useState('')
    const [type, setType] = useState('')
    const [status, setStatus] = useState('')

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const saveHandler = (title, year, imdb, type, status) => {
        axios.post('/films.json', { title: title, year: year, imdb: imdb, type: type, status: status })
            .then((response) => {
                handleShow()
            })
            .catch((error) => {
            })
    }
    return (
        <main className="add-page">
            <h2>Add New Movie/Serie to your list</h2>
            <br></br>
            <Form>
                <Form.Group>
                    <Form.Label>Title of the Movie/Serie</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Title"
                        value={title}
                        onChange={(event) => {
                            setTitle(event.target.value)
                        }} />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Year of release</Form.Label>
                    <Form.Control
                        type="number"
                        min="1900"
                        max="2099"
                        step="1"
                        placeholder="Year"
                        value={year}
                        onChange={(event) => {
                            setYear(event.target.value)
                        }} />
                </Form.Group>
                <Form.Group>
                    <Form.Label>IMDB Rate</Form.Label>
                    <Form.Control
                        type="number"
                        placeholder="IMDB"
                        step="0.1"
                        min="1"
                        max="10"
                        value={imdb}
                        onChange={(event) => {
                            setIMDB(event.target.value)
                        }} />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Type</Form.Label>
                    <Form.Control
                        as="select"
                        value={type}
                        onChange={(event) => {
                            setType(event.target.value)
                        }}>
                        <option>Choose</option>
                        <option>Movie</option>
                        <option>Animation</option>
                        <option>Serie</option>
                    </Form.Control>
                </Form.Group>
                <Form.Group>
                    <Form.Label>Watched/NotWatched</Form.Label>
                    <Form.Control
                        as="select"
                        value={status}
                        onChange={(event) => {
                            setStatus(event.target.value)
                        }}>
                        <option>Choose</option>
                        <option>Watched</option>
                        <option>Not Watched</option>
                    </Form.Control>
                </Form.Group>
                <Button className="button" onClick={() => saveHandler(title, year, imdb, type, status)}>
                    Save
                </Button>
            </Form>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Success!</Modal.Title>
                </Modal.Header>
                <Modal.Body>Your New Movie/Serie is Added to the List</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
            </Button>
                    <Button className="button" onClick={handleClose}>
                        Understood
            </Button>
                </Modal.Footer>
            </Modal>
        </main>
    )
}

export default Add