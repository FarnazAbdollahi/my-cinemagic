import './App.css';
import SideNav from '../src/Components/SideNav/SideNav'
import {
  BrowserRouter as Router, Route, Switch
} from "react-router-dom";
import HomePage from '../src/Container/HomePage/HomePage'
import WatchedList from '../src/Container/WatchedList/WatchedList'
import Add from '../src/Container/AddPage/Add'


const App = () => {
  return (
    <Router>
      <SideNav />
      <Switch>
        <Route path="/" exact component={HomePage} />
        <Route path="/add-page" exact component={Add} />
        <Route path="/watched-page" component={WatchedList} />
      </Switch>

    </Router>
  );
}

export default App;
