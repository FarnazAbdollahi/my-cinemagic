import React, { useState, useEffect } from 'react'
import './HomePage.css'
import { Table } from 'react-bootstrap'
import InfiniteScroll from 'react-infinite-scroll-component'

import Film from '../../Components/Film/Film'
import axios from '../../axios-movies'
const HomePage = () => {


    const [films, setFilmInfo] = useState([])
    const [current, setCurrent] = useState([])


    useEffect(() => {

        axios.get('https://mycinemagic99-default-rtdb.firebaseio.com/completeList/-MO5y6h_gmA8lSO5i_2D.json')
            .then((response) => {
                if (response.data === null) {
                    document.querySelector(".watch-list").innerHTML = "Nothing on the list yet"
                }
                else {
                    console.log(response.data)
                    let film = []
                    for (let i = 0; i < response.data.length; i++) {
                        film.push({
                            key: i,
                            title: response.data[i].title,
                            year: response.data[i].year,
                            imdb: response.data[i].imdb,
                            genre: response.data[i].genre,
                        })
                    }
                    setFilmInfo(film)
                    setCurrent(films.slice(0, 15))
                }
            })
    })


    const [count, setCount] = useState({

        prev: 0,
        next: 15
    })
    const [hasMore, setHasMore] = useState(true);

    const getMoreData = () => {
        if (current.length === films.length) {
            setHasMore(false);
            return;
        }
        setTimeout(() => {
            setCurrent(current.concat(films.slice(count.prev + 15, count.next + 15)))
        }, 2000)
        setCount((prevState) => ({ prev: prevState.prev + 15, next: prevState.next + 15 }))
    }


    console.log(films)
    return (
        <main className="home-page">
            <h1>Welcome!</h1>

            <InfiniteScroll
                dataLength={current.length}
                next={getMoreData}
                hasMore={hasMore}
                loader={<h4>Loading...</h4>}
            >
                <Table className="table-hover table">
                    <thead className="thead">
                        <tr>
                            <th>Title</th>
                            <th>Year</th>
                            <th>IMDB</th>
                            <th>Genre</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            current && current.map((item, index) => {
                                return (
                                    <tr key={index}>
                                        <td>{item.title}</td>
                                        <td>{item.year}</td>
                                        <td>{item.imdb}</td>
                                        <td>{item.genre}</td>
                                        <td>{item.status}</td>
                                    </tr>
                                )
                            })
                        }

                    </tbody>
                </Table>

            </InfiniteScroll>
        </main>
    )
}

export default HomePage